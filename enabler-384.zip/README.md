# hi-fi-audio-enabler-oneplus-9r-mod

modded hifi audio enabler, tested working for Roon with L&P W2

